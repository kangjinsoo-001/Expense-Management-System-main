require "test_helper"

class RequestTemplateApprovalRuleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
