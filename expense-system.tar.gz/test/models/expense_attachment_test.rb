require "test_helper"

class ExpenseAttachmentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
