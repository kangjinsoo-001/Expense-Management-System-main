require "test_helper"

class ExpenseItemApprovalTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
