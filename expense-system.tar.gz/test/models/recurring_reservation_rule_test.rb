require "test_helper"

class RecurringReservationRuleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
