require "test_helper"

class ApproverGroupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
