require "test_helper"

class RequestFormAttachmentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
