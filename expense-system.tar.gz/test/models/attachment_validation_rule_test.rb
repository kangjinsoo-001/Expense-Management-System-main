require "test_helper"

class AttachmentValidationRuleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
