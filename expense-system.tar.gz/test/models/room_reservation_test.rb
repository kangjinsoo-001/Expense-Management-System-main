require "test_helper"

class RoomReservationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
