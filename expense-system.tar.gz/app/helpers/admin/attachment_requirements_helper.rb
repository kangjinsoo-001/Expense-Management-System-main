module Admin::AttachmentRequirementsHelper
end
