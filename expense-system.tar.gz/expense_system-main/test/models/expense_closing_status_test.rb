require "test_helper"

class ExpenseClosingStatusTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
