require "test_helper"

class RequestTemplateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
