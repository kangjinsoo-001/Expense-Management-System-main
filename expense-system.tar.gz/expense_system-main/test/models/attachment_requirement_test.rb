require "test_helper"

class AttachmentRequirementTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
