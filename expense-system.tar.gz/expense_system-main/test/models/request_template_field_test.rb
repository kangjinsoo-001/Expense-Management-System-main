require "test_helper"

class RequestTemplateFieldTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
