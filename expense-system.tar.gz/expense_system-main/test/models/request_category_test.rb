require "test_helper"

class RequestCategoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
