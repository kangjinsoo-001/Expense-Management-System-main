require "test_helper"

class ExtractTextFromAttachmentJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
